<?php
if (!defined('ABSPATH')) exit;

function psp_batch_compress(){
    check_ajax_referer('psp_batch_action', 'nonce');
    if(!current_user_can('manage_options')){
        wp_send_json_error('权限不足');
        return;
    }
    
    $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : [];
    $action = isset($_POST['batch_action']) ? sanitize_text_field($_POST['batch_action']) : 'compress';
    
    if(empty($ids)){
        $imgs = get_posts([
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => -1,
            'fields' => 'ids'
        ]);
        $ids = $imgs;
    }
    
    if(empty($ids)){
        wp_send_json_error('没有找到图片');
        return;
    }
    
    $success = 0;
    $failed = 0;
    $errors = [];
    
    // Set time limit for large batches
    @set_time_limit(300);
    
    foreach($ids as $id){
        $file = get_attached_file($id);
        if($file && file_exists($file)){
            try {
                // Get file info for better error reporting
                $status = psp_get_compression_status($file);
                if(!empty($status['error'])){
                    $failed++;
                    $errors[] = sprintf('ID %d: %s', $id, $status['error']);
                    continue;
                }
                
                $result = psp_compress_image($file);
                if($result){
                    $success++;
                } else {
                    $failed++;
                    $errors[] = sprintf('ID %d: 处理失败（可能是文件格式不支持或内存不足）', $id);
                }
            } catch(Exception $e){
                $failed++;
                $errors[] = sprintf('ID %d: %s', $id, $e->getMessage());
            }
        } else {
            $failed++;
            $errors[] = sprintf('ID %d: 文件不存在', $id);
        }
    }
    
    $message = sprintf('处理完成：成功 %d 张，失败 %d 张', $success, $failed);
    if($failed > 0 && count($errors) <= 10){
        $message .= '<br>错误详情：' . implode(', ', array_slice($errors, 0, 10));
    }
    
    wp_send_json_success($message);
}
